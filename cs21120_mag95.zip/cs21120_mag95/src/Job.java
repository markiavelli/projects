package uk.ac.aber.cs21120.solution;

import uk.ac.aber.cs21120.hospital.IJob;

public class Job implements IJob,Comparable<IJob> {
    private int ID, priority,duration;
    private int initialTime,ticks;

    /**
     * Constructor providing an ID, a priority and a duration.
     * @param ID
     * @param priority
     * @param duration
     */
    public Job(int ID, int priority, int duration) {
        this.ID = ID;
        this.priority = priority;
        this.duration = duration;
    }

    /**
     * Returns ID
     * @return int containing a job's id.
     */
    @Override
    public int getID() {
        return ID;
    }

    /**
     * Returns the priority
     * @return int containing a job's priority.
     */
    @Override
    public int getPriority() {
        return priority;
    }

    /**
     * Increase the number of ticks a job has used.
     */
    @Override
    public void tick() {
        ticks++;

    }

    /**
     * Determines if a job is done.
     * @return boolean indicating if the job is done or not
     */
    @Override
    public boolean isDone() {
        if (ticks>=duration){
            return true;
        }
        return false;
    }

    /**
     * Returns the time the job has spent in the simulator.
     * @param now		the current simulator tick number
     * @return The difference between the currentTime and the time when the job was added to the Simulator.
     */
    @Override
    public int getTimeSinceSubmit(int now) {
        if(now<=initialTime) throw new RuntimeException("The job has not been added to the simulation.");
        return now-initialTime;
    }

    /**
     * Sets initialTime to the moment the job was added to the simulator.
     * @param time		the time at which the job was added to the simulator
     */
    @Override
    public void setInitialTime(int time) {
        initialTime =time;
    }

    /**
     * Compares the current job's priority with the priority of the job passed as a parameter.
     * If the returned integer is positive, current job is more important. If negative, is less important.
     * If 0, they have the same priority.
     * @param o The job we want to compare the current job with.
     * @return integer indicating the difference in priorities.
     */
    @Override
    public int compareTo(IJob o) {
        return priority-o.getPriority();
    }
}
