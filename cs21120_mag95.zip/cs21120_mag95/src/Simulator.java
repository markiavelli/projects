package uk.ac.aber.cs21120.solution;

import uk.ac.aber.cs21120.hospital.IJob;
import uk.ac.aber.cs21120.hospital.ISimulator;
import uk.ac.aber.cs21120.hospital.RandomPriorityGenerator;

import java.util.*;


public class Simulator implements ISimulator {
   private PriorityQueue<Job> waiting= new PriorityQueue<>();
   private Set<Job>running= new HashSet<>();

   private int time=0;
   private int ambulances;

   private HashMap<Integer,Integer> priorityOccurrences= new HashMap<>();
   private HashMap<Integer,Integer> totalTimes= new HashMap<>();

   final static private int N_ITERATIONS =10000;

    /**
     * Constructor providing the number of initial ambulances.
     * @param ambulances
     */
    public Simulator(int ambulances) {
        this.ambulances = ambulances;
    }


    public static void main(String[] args)
    {
        System.out.println("-----TASK 3-----");
        task3(4);
        System.out.println();
        System.out.println("-----TASK 4-----");
        task4();
    }



    /**
     * Adds a job to the Simulator.
     * If there are no ambulances available, it will add it to the waiting list.
     * If there are ambulances available, it will add them to the running list and reduce the number of ambulances.
     * In either case, it will record the initial time the job entered the simulator.
     * @param j The job to be added.
     */
    @Override
    public void add(IJob j) {
        if (ambulances == 0) {
            waiting.add((Job) j);

        }
        else
            {
            running.add((Job) j);
            ambulances--;
            }
        j.setInitialTime(getTime());
    }

    /**
     * Updates running and waiting jobs. Increases the ticks of the simulator.
     */
    @Override
    public void tick() {
       runningJobsUpdate();
       waitingJobsUpdate();
       time++;
    }

    /**
     * Returns the current time.
     * @return integer indicating the ticks in the current moment.
     */
    @Override
    public int getTime() {
        return time;
    }

    /**
     * Determines if all the jobs have been done.
     * @return boolean indicating if all running and waiting jobs have been dispatched.
     */
    @Override
    public boolean allDone() {
        return running.isEmpty() && waiting.isEmpty();
    }

    /**
     * Returns a set with the IDs of all the running jobs.
     * @return set of integers
     */
    @Override
    public Set<Integer> getRunningJobs() {
        Set<Integer> runningJobs= new TreeSet<>();
        for(Job j : running)
        {
            runningJobs.add(j.getID());
        }
        return runningJobs;
    }


    @Override
    public double getAverageJobCompletionTime(int priority) {

        int dividend= totalTimes.get(priority);
        int divisor=priorityOccurrences.get(priority);

        return dividend/divisor;
    }

    /**
     * Updates the running jobs.
     * Traverses all the running jobs and removes those that are done, storing in maps their information according
     * to their priority.
     * If a job is completed, ambulances are freed.
     *
     */
    public void runningJobsUpdate()
    {
        LinkedHashSet<Job> disposable= new LinkedHashSet<>();

            for (Job j : running) {
                //Avoid possible null values
                if(j!=null) {
                    j.tick();
                    if (j.isDone()) {
                        disposable.add(j);
                        ambulances++;
                        //If the key exists in the Occurrences Map, counter is increased.
                        if (priorityOccurrences.containsKey(j.getPriority())) {
                            priorityOccurrences.put(j.getPriority(), priorityOccurrences.get(j.getPriority()) + 1);
                        }
                        //Else, the element is added and the counter is set to 1.
                        else {
                            priorityOccurrences.put(j.getPriority(), 1);
                        }
                        //If the key exists in the Times Map, its time is added to the previous times.
                        if (totalTimes.containsKey(j.getPriority())) {
                            totalTimes.put(j.getPriority(), totalTimes.get(j.getPriority()) + j.getTimeSinceSubmit(getTime()));
                        }
                        //Else, the key is added and its value is initialized with the job's time.
                        else {
                            totalTimes.put(j.getPriority(), j.getTimeSinceSubmit(getTime()));
                        }

                    }

                }
                //Facilitate the garbage collector the elimination of null values.
                else{disposable.add(j);}
        }

        running.removeAll(disposable);
    }

    /**
     * Updates the waiting jobs.
     * If the waiting list is not empty and there are free ambulances, a new job from the waiting queue
     * will be assigned to a free ambulance.
     */
    public void waitingJobsUpdate() {
        if (ambulances > 0 && !waiting.isEmpty()) {
            while (ambulances!=0) {
                running.add(waiting.poll());
                ambulances--;
            }
        }
    }

    public HashMap<Integer, Integer> getPriorityOccurrences() {
        return priorityOccurrences;
    }

    public HashMap<Integer, Integer> getTotalTimes() {
        return totalTimes;
    }

    private static void task3(int ambulances)
    {
        int i=1;
        Simulator theSims= new Simulator(ambulances);
        RandomPriorityGenerator gen= new RandomPriorityGenerator();

        //10000 ticks
        while(i< N_ITERATIONS)
        {
            theSims.tick();
            int rand=(int)(Math.random()*(4-1)+1);
            //1/3 possibilities of creating a new randomly generated job. Id will be the tick in which it appeared.
            if(rand==1)
            {
                int duration= (int)(Math.random()*(21-10)+10);
                int priority= gen.next();
                Job newJob= new Job(i,priority,duration);

                theSims.add(newJob);
               // System.out.println("Job with the ID "+ i+" added to the simulator correctly.");
            }
            i++;
        }
        System.out.println("First "+i +" ticks finished.");
        System.out.println("Finishing pending jobs");
        while(!theSims.allDone())
        {
            theSims.tick();

            i++;
        }
        System.out.println("All jobs finished at "+i+" ticks.");
        for (int k=0;k<4;k++) {
            if(theSims.getPriorityOccurrences().containsKey(k)&& theSims.getTotalTimes().containsKey(k)){
            double totaltime=theSims.getAverageJobCompletionTime(k);
            System.out.println("The average completion time for priority "+k+" was "+ totaltime+ " ticks.");
            }
        }
    }

    private static void task4() {
        for(int i=4; i<21;i++)
        {
            System.out.println();
            System.out.println("----------Simulation with "+i+" ambulances----------");
            task3(i);
        }

    }

}
