package uk.ac.aber.cs21120.solution;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class SimulatorCrashTest {

    @Test
    public void Remove3atATime() {
      Simulator sim= new Simulator(6);
      for(int i=0; i<3; i++)
      {
          sim.add(new Job(i,1,3));
      }
      sim.add(new Job(666,1,6));
        sim.add(new Job(667,1,6));
        sim.add(new Job(668,1,6));
        sim.add(new Job(669,1,6));
        sim.add(new Job(670,1,6));
        sim.add(new Job(671,1,6));
      for(int j=0;j<3;j++)
      {
          sim.tick();
      }
      Assertions.assertEquals(6,sim.getRunningJobs().size());
    }
}
